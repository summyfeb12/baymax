var firebase = require('firebase');

// Initialize Firebase
  var config = {
    apiKey: "AIzaSyDaxfHggITB6xgUisng-De2gv-6cazokPk",
    authDomain: "eatwell-ef0a5.firebaseapp.com",
    databaseURL: "https://eatwell-ef0a5.firebaseio.com",
    storageBucket: "eatwell-ef0a5.appspot.com",
    messagingSenderId: "62698950727"
  };

firebase.initializeApp(config);

// Get a database reference to our posts
var db = firebase.database();
var ref = db.ref("Food");

// Attach an asynchronous callback to read the data at our posts reference
ref.on("value", function(snapshot) {
  console.log(snapshot.val());
  return;
}, function (errorObject) {
  console.log("The read failed: " + errorObject.code);
});
